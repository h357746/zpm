<template>
  <div id="app">
    <div id="nav">
      <router-link to="/"></router-link>

    </div>
    <router-view/>
  </div>
</template>

<style lang="scss">
@import '../src/style/index.scss';
</style>
